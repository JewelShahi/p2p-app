// api/socket.js
// Robust singleton socket tuned for flaky mobile networks.
// Key mobile fix: long-ish timeouts + infinite retries, so a phone that
// backgrounds (e.g. opening the gallery) reconnects instead of dying.
import { io } from 'socket.io-client';

const URL =
  import.meta.env.VITE_SERVER_URL ||
  import.meta.env.VITE_API_URL ||
  'http://localhost:4000';

const socket = io(URL, {
  autoConnect: true,
  transports: ['websocket'],   // skip long-polling; faster + fewer dupes
  reconnection: true,
  reconnectionAttempts: Infinity,
  reconnectionDelay: 800,
  reconnectionDelayMax: 4000,
  timeout: 20000,
});

// Optional: tiny visibility helper you can import anywhere.
// Reconnects the instant a backgrounded tab (phone gallery, app switch)
// comes back to the foreground.
export function wireVisibilityReconnect() {
  const kick = () => {
    if (document.visibilityState === 'visible' && socket.disconnected) {
      socket.connect();
    }
  };
  document.addEventListener('visibilitychange', kick);
  window.addEventListener('pageshow', kick);
  window.addEventListener('online', kick);
  // return an unsubscribe for cleanup in useEffect
  return () => {
    document.removeEventListener('visibilitychange', kick);
    window.removeEventListener('pageshow', kick);
    window.removeEventListener('online', kick);
  };
}

export default socket;

// signaling.js
// Handles create/join/reconnect + WebRTC offer/answer/ICE relaying.
//
// IMPORTANT: your original signaling.js was not included, so the event names below
// are my reconstruction. Match these names in your frontend (see client/connection.js).
// If your frontend already uses different names, either rename here or there — but
// keep the *reconnect* + *persistent userId* logic exactly as-is; that's the fix.

import { isValidDuration, isValidUserId } from './roomManager.js';

const ack = (fn, val) => {
  if (typeof fn === 'function') fn(val);
};

const cleanRoomId = (v) => {
  if (typeof v !== 'string') return null;
  const s = v.trim();
  return s.length >= 8 && s.length <= 128 ? s : null;
};

export function registerSignaling(io, roomManager) {
  io.on('connection', (socket) => {
    // ---- HOST creates a room ------------------------------------------------
    socket.on('create-room', async (payload = {}, cb) => {
      try {
        const { userId, durationMinutes } = payload;
        if (!isValidUserId(userId)) return ack(cb, { ok: false, error: 'invalid-user-id' });

        const room = roomManager.createRoom({
          hostSocketId: socket.id,
          hostUserId: userId,
          durationMinutes: isValidDuration(durationMinutes) ? durationMinutes : undefined,
        });
        await socket.join(room.id);
        roomManager.emitPresence(room.id);

        ack(cb, {
          ok: true,
          roomId: room.id,
          userId: room.hostUserId,
          expiresAt: room.expiresAt,
          remainingSeconds: roomManager.remainingSeconds(room.id),
        });
      } catch (e) {
        console.error('[create-room]', e);
        ack(cb, { ok: false, error: 'create-room-failed' });
      }
    });

    // ---- HOST reconnects after refresh / phone background -------------------
    socket.on('reconnect-host', async (payload = {}, cb) => {
      const roomId = cleanRoomId(payload.roomId);
      const userId = payload.userId;
      if (!roomId || !isValidUserId(userId)) return ack(cb, { ok: false, error: 'invalid-reconnect' });

      const room = roomManager.reconnectHost(roomId, userId, socket.id);
      if (!room) return ack(cb, { ok: false, error: 'host-reconnect-rejected' });

      await socket.join(roomId);
      socket.to(roomId).emit('host-reconnected', { roomId, hostSocketId: socket.id, hostUserId: userId });
      roomManager.emitPresence(roomId);

      ack(cb, {
        ok: true,
        roomId,
        expiresAt: room.expiresAt,
        remainingSeconds: roomManager.remainingSeconds(roomId),
        peers: roomManager.getLiveMembers(roomId),
      });
    });

    // ---- PEER joins OR reconnects (ghost-user fix) --------------------------
    socket.on('join-room', async (payload = {}, cb) => {
      const roomId = cleanRoomId(payload.roomId);
      const userId = payload.userId;
      if (!roomId || !isValidUserId(userId)) return ack(cb, { ok: false, error: 'invalid-join' });

      const room = roomManager.getRoom(roomId);
      if (!roomManager.isJoinable(room)) {
        return ack(cb, { ok: false, error: room ? 'room-not-joinable' : 'room-not-found' });
      }
      if (room.hostUserId === userId) {
        return ack(cb, { ok: false, error: 'host-must-reconnect-as-host' });
      }

      const result = roomManager.addOrReconnectMember(roomId, socket.id, userId);
      if (!result) return ack(cb, { ok: false, error: 'join-failed' });

      await socket.join(roomId);

      io.to(room.hostSocketId).emit(result.reconnected ? 'peer-reconnected' : 'peer-joined', {
        roomId,
        peerSocketId: socket.id,
        peerUserId: result.member.userId,
        reconnected: result.reconnected,
      });
      roomManager.emitPresence(roomId);

      ack(cb, {
        ok: true,
        roomId,
        userId: result.member.userId,
        hostSocketId: room.hostSocketId,
        hostUserId: room.hostUserId,
        reconnected: result.reconnected,
        currentOffer: room.currentOffer, // lets a reconnecting peer re-negotiate
        remainingSeconds: roomManager.remainingSeconds(roomId),
      });
    });

    // ---- WebRTC signaling relays -------------------------------------------
    socket.on('offer', (payload = {}, cb) => {
      const m = roomManager.getMembership(socket.id);
      if (!m || m.role !== 'host') return ack(cb, { ok: false, error: 'only-host-can-offer' });
      if (!payload.offer) return ack(cb, { ok: false, error: 'missing-offer' });

      const room = roomManager.setOffer(m.roomId, payload.offer);
      if (!room) return ack(cb, { ok: false, error: 'room-not-found' });

      const data = { roomId: room.id, offer: payload.offer, hostSocketId: socket.id, hostUserId: room.hostUserId };
      if (payload.targetSocketId) io.to(payload.targetSocketId).emit('offer', data);
      else socket.to(room.id).emit('offer', data);
      ack(cb, { ok: true });
    });

    socket.on('answer', (payload = {}, cb) => {
      const m = roomManager.getMembership(socket.id);
      if (!m) return ack(cb, { ok: false, error: 'not-in-room' });
      const room = roomManager.getRoom(m.roomId);
      if (!room) return ack(cb, { ok: false, error: 'room-not-found' });

      io.to(room.hostSocketId).emit('answer', {
        roomId: room.id,
        answer: payload.answer,
        peerSocketId: socket.id,
        peerUserId: m.userId,
      });
      ack(cb, { ok: true });
    });

    socket.on('ice-candidate', (payload = {}) => {
      const m = roomManager.getMembership(socket.id);
      if (!m) return;
      const room = roomManager.getRoom(m.roomId);
      if (!room) return;

      // Host -> targeted peer; Peer -> host.
      if (m.role === 'host' && payload.targetSocketId) {
        io.to(payload.targetSocketId).emit('ice-candidate', {
          candidate: payload.candidate,
          fromSocketId: socket.id,
        });
      } else {
        io.to(room.hostSocketId).emit('ice-candidate', {
          candidate: payload.candidate,
          fromSocketId: socket.id,
          peerUserId: m.userId,
        });
      }
    });

    // Optional: explicit "I'm leaving for good" from a Close button.
    socket.on('leave-room', () => {
      const m = roomManager.getMembership(socket.id);
      if (!m) return;
      if (m.role === 'peer') {
        roomManager.cancelPeerDisconnect(m.roomId, m.userId);
        roomManager.removeMemberByUserId(m.roomId, m.userId);
        const room = roomManager.getRoom(m.roomId);
        if (room) {
          io.to(room.hostSocketId).emit('peer-left', { peerUserId: m.userId, peerSocketId: socket.id, disconnected: false });
          roomManager.emitPresence(m.roomId);
        }
      }
    });

    // ---- Disconnect: use grace timers, never insta-remove ------------------
    socket.on('disconnect', () => {
      const m = roomManager.getMembership(socket.id);
      if (!m) return;
      roomManager.socketMemberships.delete(socket.id);

      if (m.role === 'host') {
        const room = roomManager.getRoom(m.roomId);
        if (room && room.hostSocketId === socket.id) {
          roomManager.scheduleHostDisconnect(m.roomId, socket.id);
        }
      } else {
        roomManager.schedulePeerDisconnect(m.roomId, socket.id, m.userId);
      }
    });
  });
}

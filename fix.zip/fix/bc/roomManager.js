// roomManager.js
// FIX 1 (ghost users): members are keyed by a PERSISTENT userId that the browser
//   stores in localStorage — not by socketId. Refreshing replaces the socket on the
//   same member instead of creating a new one.
// FIX 2 (mobile gallery): reconnecting with the same userId cancels the pending
//   "leave" timer, so a phone that briefly backgrounds does NOT get reported as left.
import { randomUUID } from 'node:crypto';

const MIN_DURATION = 10;
const MAX_DURATION = 60;
const STEP = 5;
const DEFAULT_DURATION = 20;

// How long we wait before really removing a peer/host that vanished.
// 2 min is plenty for a phone opening the gallery, and short enough to clean up.
const DISCONNECT_GRACE_MS = 2 * 60 * 1000;

const isValidDuration = (minutes) => {
  if (!Number.isInteger(minutes)) return false;
  if (minutes < MIN_DURATION || minutes > MAX_DURATION) return false;
  return (minutes - MIN_DURATION) % STEP === 0;
};

// A client-supplied id (from localStorage). Keep it strict so it can't be abused.
const isValidUserId = (value) =>
  typeof value === 'string' &&
  value.length >= 8 &&
  value.length <= 128 &&
  /^[a-zA-Z0-9_-]+$/.test(value);

class RoomManager {
  constructor(io) {
    this.io = io;
    this.rooms = new Map();
    // socketId -> { roomId, userId, role } so disconnect handling is O(1)
    this.socketMemberships = new Map();
  }

  createRoom({ hostSocketId, hostUserId, durationMinutes }) {
    const hostId = isValidUserId(hostUserId) ? hostUserId : randomUUID();
    const duration = isValidDuration(durationMinutes) ? durationMinutes : DEFAULT_DURATION;
    const roomId = randomUUID();
    const now = Date.now();
    const expiresAt = now + duration * 60 * 1000;

    const room = {
      id: roomId,
      hostSocketId,
      hostUserId: hostId,
      createdAt: now,
      durationMinutes: duration,
      expiresAt,
      status: 'open',
      members: new Map(), // key: persistent userId
      currentOffer: null,
      expiryTimer: null,
      hostDisconnectTimer: null,
      pendingLeaves: new Map(), // key: userId -> { timer, socketId }
    };

    room.expiryTimer = setTimeout(() => this.closeRoom(roomId, 'expired'), Math.max(0, expiresAt - now));
    room.expiryTimer.unref?.();

    this.rooms.set(roomId, room);
    this.socketMemberships.set(hostSocketId, { roomId, userId: hostId, role: 'host' });
    return room;
  }

  getRoom(roomId) {
    return this.rooms.get(roomId);
  }

  getMembership(socketId) {
    return this.socketMemberships.get(socketId) || null;
  }

  isJoinable(room) {
    return !!room && room.status === 'open' && Date.now() < room.expiresAt;
  }

  // --- HOST reconnect (after a refresh or phone background) ------------------
  reconnectHost(roomId, userId, newSocketId) {
    const room = this.getRoom(roomId);
    if (!room || room.status !== 'open') return null;
    if (room.hostUserId !== userId) return null;

    const oldSocketId = room.hostSocketId;
    this.cancelHostDisconnect(roomId);

    room.hostSocketId = newSocketId;
    this.socketMemberships.set(newSocketId, { roomId, userId, role: 'host' });

    if (oldSocketId && oldSocketId !== newSocketId) {
      this.socketMemberships.delete(oldSocketId);
      const oldSock = this.io.sockets.sockets.get(oldSocketId);
      if (oldSock) {
        oldSock.leave(roomId);
        oldSock.emit('session-replaced', { roomId, reason: 'host-reconnected' });
        oldSock.disconnect(true);
      }
    }
    return room;
  }

  // --- PEER join OR reconnect (this is the ghost-user fix) ------------------
  addOrReconnectMember(roomId, socketId, requestedUserId) {
    const room = this.getRoom(roomId);
    if (!this.isJoinable(room)) return null;

    const userId = isValidUserId(requestedUserId) ? requestedUserId : randomUUID();

    // If this same person was "leaving", cancel that — they're back.
    this.cancelPeerDisconnect(roomId, userId);

    const existing = room.members.get(userId);
    const oldSocketId = existing?.socketId || null;

    const member = {
      userId,
      socketId,
      joinedAt: existing?.joinedAt || Date.now(),
      reconnectedAt: existing ? Date.now() : null,
      downloading: existing?.downloading || new Set(),
    };
    room.members.set(userId, member); // replace, never duplicate

    this.socketMemberships.set(socketId, { roomId, userId, role: 'peer' });

    // Kill the stale socket from the previous refresh so it can't emit anything.
    if (oldSocketId && oldSocketId !== socketId) {
      this.socketMemberships.delete(oldSocketId);
      const oldSock = this.io.sockets.sockets.get(oldSocketId);
      if (oldSock) {
        oldSock.leave(roomId);
        oldSock.emit('session-replaced', { roomId, reason: 'peer-reconnected' });
        oldSock.disconnect(true);
      }
    }

    return {
      member,
      reconnected: !!existing,
      replacedSocketId: oldSocketId !== socketId ? oldSocketId : null,
    };
  }

  removeMemberByUserId(roomId, userId) {
    const room = this.getRoom(roomId);
    if (!room) return null;
    const member = room.members.get(userId);
    if (!member) return null;
    room.members.delete(userId);
    this.socketMemberships.delete(member.socketId);
    return member;
  }

  getLiveMembers(roomId) {
    const room = this.getRoom(roomId);
    if (!room) return [];
    const out = [];
    for (const m of room.members.values()) {
      if (this.io.sockets.sockets.has(m.socketId)) out.push({ socketId: m.socketId, userId: m.userId });
    }
    return out;
  }

  getPeerCount(roomId) {
    return this.getLiveMembers(roomId).length;
  }

  setOffer(roomId, offer) {
    const room = this.getRoom(roomId);
    if (!room) return null;
    room.currentOffer = offer;
    return room;
  }

  // --- HOST disconnect handling --------------------------------------------
  scheduleHostDisconnect(roomId, expectedSocketId, graceMs = DISCONNECT_GRACE_MS) {
    const room = this.getRoom(roomId);
    if (!room) return;
    if (room.hostDisconnectTimer) clearTimeout(room.hostDisconnectTimer);

    room.hostDisconnectTimer = setTimeout(() => {
      room.hostDisconnectTimer = null;
      // If host already reconnected on a new socket, do nothing.
      if (room.hostSocketId !== expectedSocketId) return;
      this.closeRoom(roomId, 'host-disconnected');
    }, graceMs);
    room.hostDisconnectTimer.unref?.();
  }

  cancelHostDisconnect(roomId) {
    const room = this.getRoom(roomId);
    if (!room?.hostDisconnectTimer) return;
    clearTimeout(room.hostDisconnectTimer);
    room.hostDisconnectTimer = null;
  }

  // --- PEER disconnect handling (mobile-friendly) --------------------------
  schedulePeerDisconnect(roomId, socketId, userId, graceMs = DISCONNECT_GRACE_MS) {
    const room = this.getRoom(roomId);
    if (!room || !userId) return;

    const member = room.members.get(userId);
    // Ignore a disconnect coming from an already-replaced (old) socket.
    if (!member || member.socketId !== socketId) return;

    const existing = room.pendingLeaves.get(userId);
    if (existing) clearTimeout(existing.timer);

    const timer = setTimeout(() => {
      room.pendingLeaves.delete(userId);
      const current = room.members.get(userId);
      if (!current || current.socketId !== socketId) return; // they came back
      this.removeMemberByUserId(roomId, userId);
      this.io.to(room.hostSocketId).emit('peer-left', {
        peerSocketId: socketId,
        peerUserId: userId,
        disconnected: true,
      });
      this.emitPresence(roomId);
    }, graceMs);
    timer.unref?.();

    room.pendingLeaves.set(userId, { timer, socketId });

    // Tell the host "hang on, reconnecting" — NOT "left".
    this.io.to(room.hostSocketId).emit('peer-reconnecting', {
      peerSocketId: socketId,
      peerUserId: userId,
      graceMs,
    });
  }

  cancelPeerDisconnect(roomId, userId) {
    const room = this.getRoom(roomId);
    if (!room) return;
    const pending = room.pendingLeaves.get(userId);
    if (!pending) return;
    clearTimeout(pending.timer);
    room.pendingLeaves.delete(userId);
  }

  emitPresence(roomId) {
    const room = this.getRoom(roomId);
    if (!room) return;
    const peers = this.getLiveMembers(roomId);
    this.io.to(roomId).emit('room-presence', { roomId, peerCount: peers.length, peers });
  }

  closeRoom(roomId, reason = 'terminated') {
    const room = this.getRoom(roomId);
    if (!room || room.status !== 'open') return;

    if (room.expiryTimer) clearTimeout(room.expiryTimer);
    if (room.hostDisconnectTimer) clearTimeout(room.hostDisconnectTimer);
    for (const { timer } of room.pendingLeaves.values()) clearTimeout(timer);
    room.pendingLeaves.clear();

    room.status = reason === 'expired' ? 'expired' : 'closed';
    this.io.to(roomId).emit('room-closed', { roomId, reason });

    this.socketMemberships.delete(room.hostSocketId);
    for (const m of room.members.values()) this.socketMemberships.delete(m.socketId);

    const t = setTimeout(() => this.rooms.delete(roomId), 5000);
    t.unref?.();
  }

  remainingSeconds(roomId) {
    const room = this.getRoom(roomId);
    if (!room) return 0;
    return Math.max(0, Math.ceil((room.expiresAt - Date.now()) / 1000));
  }

  sweep() {
    const now = Date.now();
    for (const [roomId, room] of this.rooms.entries()) {
      if (room.status === 'open' && now >= room.expiresAt) this.closeRoom(roomId, 'expired');
    }
  }
}

export {
  RoomManager,
  isValidDuration,
  isValidUserId,
  MIN_DURATION,
  MAX_DURATION,
  STEP,
  DEFAULT_DURATION,
  DISCONNECT_GRACE_MS,
};
